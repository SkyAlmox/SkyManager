/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/

import React from 'react';
import ProductGallery from './components/ProductGallery';
import { Product, JournalArticle } from './types';

export const PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Aura Harmony',
    tagline: 'Listen naturally.',
    description: 'Audio that feels like the open air. Constructed with warm acoustic fabric and recycled sandstone composite.',
    longDescription: 'Experience sound as it was meant to be heard—unconfined and organic. The Aura Harmony headphones feature our proprietary open-air driver technology, encased in a breathable acoustic fabric that adapts to your temperature. The headband is crafted from a recycled sandstone composite, offering a unique, cool-to-the-touch texture that grounds you in the present moment.',
    price: 429,
    category: 'Audio',
    imageUrl: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=1000',
    gallery: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&q=80&w=1000',
      'https://images.unsplash.com/photo-1524678606372-565ae0f98944?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Organic Noise Cancellation', '50h Battery', 'Natural Soundstage']
  },
  {
    id: 'p2',
    name: 'Aura Epoch',
    tagline: 'Moments, not minutes.',
    description: 'A timepiece designed for wellness. Ceramic casing with a strap made from sustainable vegan leather.',
    longDescription: 'Time is not a sequence of numbers, but a flow of moments. The Aura Epoch rethinks the smartwatch interface, using a calm E-Ink hybrid display that mimics paper. It tracks stress through skin temperature and heart rate variability, gently vibrating to remind you to breathe. The ceramic casing is hypoallergenic and smooth, polished by hand for 48 hours.',
    price: 349,
    category: 'Wearable',
    imageUrl: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=1000',
    gallery: [
        'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=1000',
        'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Stress Monitoring', 'E-Ink Hybrid Display', '7-Day Battery']
  },
  {
    id: 'p3',
    name: 'Aura Canvas',
    tagline: 'Capture the warmth.',
    description: 'A display that mimics the properties of paper. Soft on the eyes, vivid in color, and textured to the touch.',
    longDescription: 'Screens shouldn\'t feel like looking into a lightbulb. Aura Canvas uses a matte, nano-etched OLED panel that scatters ambient light, creating a display that looks and feels like high-quality magazine paper. Perfect for reading, sketching, or displaying art, it brings a tactile warmth to your digital life.',
    price: 1099,
    category: 'Mobile',
    imageUrl: 'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=1000',
    gallery: [
        'https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=1000',
        'https://images.unsplash.com/photo-1585338107529-13afc5f02586?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Paper-like OLED', 'Portrait Lens', 'Sandstone Texture']
  },
  {
    id: 'p4',
    name: 'Aura Essence',
    tagline: 'Return to nature.',
    description: 'An air purifier that doubles as a sculpture. Whisper quiet, diffusing subtle natural scents while cleaning your space.',
    longDescription: 'Clean air is the foundation of a clear mind. Aura Essence uses a moss-based bio-filter combined with HEPA technology to scrub pollutants from your home. It gently diffuses natural essential oils—cedar, bergamot, and rain—orchestrated to match the time of day.',
    price: 599,
    category: 'Home',
    imageUrl: 'https://images.pexels.com/photos/8092420/pexels-photo-8092420.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    gallery: [
        'https://images.pexels.com/photos/8092420/pexels-photo-8092420.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Bio-HEPA Filter', 'Aromatherapy', 'Silent Night Mode']
  },
  {
    id: 'p5',
    name: 'Aura Beam',
    tagline: 'Light that breathes.',
    description: 'Smart circadian lighting that follows the sun. Casts a warm, candle-like glow in the evenings.',
    longDescription: 'Artificial light disrupts our natural rhythms. Aura Beam syncs with your local sunrise and sunset, providing cool, energizing light during the day and transitioning to a warm, amber glow free of blue light in the evening. Controls are touchless; a simple wave of the hand adjusts brightness.',
    price: 249,
    category: 'Home',
    imageUrl: 'https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?auto=format&fit=crop&q=80&w=1000',
    gallery: [
        'https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?auto=format&fit=crop&q=80&w=1000',
        'https://images.unsplash.com/photo-1540932296235-d84931b6370b?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Circadian Rhythm Sync', 'Warm Dimming', 'Touchless Control']
  },
  {
    id: 'p6',
    name: 'Aura Scribe',
    tagline: 'Thought in motion.',
    description: 'A digital stylus with the friction of graphite. Charges wirelessly when magnetically attached to Aura Canvas.',
    longDescription: 'The connection between hand and brain is sacred. Aura Scribe features a custom elastomer tip that replicates the microscopic friction of graphite on paper. Weighted perfectly for balance, it disappears in your hand, leaving only your thoughts.',
    price: 129,
    category: 'Mobile',
    imageUrl: 'https://images.pexels.com/photos/2647376/pexels-photo-2647376.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
    gallery: [
        'https://images.pexels.com/photos/2647376/pexels-photo-2647376.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1',
        'https://images.unsplash.com/photo-1517260487576-8977430081d3?auto=format&fit=crop&q=80&w=1000'
    ],
    features: ['Zero Latency', 'Textured Tip', 'Wireless Charging']
  }
];

export const JOURNAL_ARTICLES: JournalArticle[] = [
    {
        id: 1,
        title: "Carregadores de Celular",
        date: "Soluções de Energia",
        excerpt: "Estações de carregamento inteligentes e seguras para ambientes públicos e privados.",
        image: "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=1000",
        content: (
            <>
                <p className="mb-12 text-brand-text/70 text-center max-w-2xl mx-auto text-xl">
                    Nossas estações de carregamento são projetadas para oferecer conveniência e segurança. Com tecnologia de carga rápida e design personalizável, elas se adaptam perfeitamente a shoppings, aeroportos e eventos.
                </p>
                <ProductGallery 
                    categories={[
                        {
                            title: 'SOB MEDIDA',
                            subtitle: 'Fotovoltaico | Indução | Por Cabo',
                            images: Array.from({ length: 15 }, (_, i) => `https://picsum.photos/seed/charger-${i}/800/600`)
                        }
                    ]}
                />
            </>
        )
    },
    {
        id: 2,
        title: "Comunicação Visual",
        date: "Identidade & Sinalização",
        excerpt: "Projetos completos de sinalização e branding que destacam sua marca no mercado.",
        image: "https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&q=80&w=1000",
        content: (
            <>
                <p className="mb-12 text-brand-text/70 text-center max-w-2xl mx-auto text-xl">
                    Transformamos sua identidade visual em realidade física. De fachadas luminosas a sistemas de sinalização interna, utilizamos materiais de alta qualidade para garantir durabilidade e impacto visual.
                </p>
                <ProductGallery />
            </>
        )
    },
    {
        id: 3,
        title: "Estruturas para Mídia OOH",
        date: "Outdoor Media",
        excerpt: "Engenharia e fabricação de estruturas robustas para publicidade externa de alto impacto.",
        image: "https://images.unsplash.com/photo-1541535650810-10d26f5c2abb?auto=format&fit=crop&q=80&w=1000",
        content: (
            <>
                <p className="mb-12 text-brand-text/70 text-center max-w-2xl mx-auto text-xl">
                    Desenvolvemos estruturas metálicas para painéis, outdoors e empenas, focando na segurança estrutural e na facilidade de manutenção para campanhas de grande escala.
                </p>
                <ProductGallery 
                    categories={[
                        {
                            title: 'MÍDIA OOH',
                            subtitle: 'Vídeos Wall | Painéis | Totens',
                            images: Array.from({ length: 15 }, (_, i) => `https://picsum.photos/seed/ooh-${i}/800/600`)
                        }
                    ]}
                />
            </>
        )
    },
    {
        id: 4,
        title: "Marcenaria",
        date: "Mobiliário Sob Medida",
        excerpt: "Mobiliário corporativo e comercial executado com precisão e acabamento superior.",
        image: "https://images.unsplash.com/photo-1611486212335-132d6282433b?auto=format&fit=crop&q=80&w=1000",
        content: (
            <>
                <p className="mb-12 text-brand-text/70 text-center max-w-2xl mx-auto text-xl">
                    Nossa marcenaria combina técnicas tradicionais com tecnologia CNC para criar peças exclusivas que otimizam espaços e reforçam a estética da sua marca.
                </p>
                <ProductGallery 
                    categories={[
                        {
                            title: 'MARCENARIA',
                            subtitle: 'x1 | x2 | x3',
                            images: Array.from({ length: 15 }, (_, i) => `https://picsum.photos/seed/wood-${i}/800/600`)
                        }
                    ]}
                />
            </>
        )
    },
    {
        id: 5,
        title: "Projetos Especiais de Arquitetura",
        date: "Arquitetura & Design",
        excerpt: "Execução de projetos arquitetônicos complexos e instalações artísticas sob medida.",
        image: "https://images.unsplash.com/photo-1503387762-592dee58c460?auto=format&fit=crop&q=80&w=1000",
        content: (
            <>
                <p className="mb-12 text-brand-text/70 text-center max-w-2xl mx-auto text-xl">
                    Trabalhamos em parceria com arquitetos para dar vida a visões audaciosas, utilizando uma vasta gama de materiais e processos de fabricação avançados.
                </p>
                <ProductGallery 
                    categories={[
                        {
                            title: 'TUDO AQUI',
                            subtitle: 'Serralheria Técnica | Pinturas Especiais | Elétrica e Eletrônica | Montagem',
                            images: Array.from({ length: 15 }, (_, i) => `https://picsum.photos/seed/arch-${i}/800/600`)
                        }
                    ]}
                />
            </>
        )
    },
    {
        id: 6,
        title: "Totens Digitais e Interativos",
        date: "Tecnologia & Interação",
        excerpt: "Hardware de ponta para sinalização digital e autoatendimento com design sofisticado.",
        image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&q=80&w=1000",
        content: (
            <>
                <p className="mb-12 text-brand-text/70 text-center max-w-2xl mx-auto text-xl">
                    Nossos totens integram tecnologia de toque e displays de alta definição em gabinetes elegantes, proporcionando uma experiência de usuário imersiva e funcional.
                </p>
                <ProductGallery 
                    categories={[
                        {
                            title: 'TOTENS',
                            subtitle: 'Autoatendimento | Digitais | Interativos',
                            images: Array.from({ length: 15 }, (_, i) => `https://picsum.photos/seed/digital-totem-${i}/800/600`)
                        }
                    ]}
                />
            </>
        )
    },
    {
        id: 7,
        title: "LEGAL!",
        date: "Vamos Conversar?",
        excerpt: "Entre em contato com a nossa equipe e tire o seu projeto do papel.",
        image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=1000",
        content: (
            <div className="space-y-12">
                <p className="text-brand-text/70 text-center max-w-2xl mx-auto text-xl leading-relaxed">
                    Agora que você conheceu um pouco do que somos capazes de fazer, transformado matérias-primas comuns em projetos exclusivos, vamos falar rapidamente sobre a nossa estrutura e como você pode entrar em contato com a gente para tirar o seu projeto do papel.
                </p>
                
                <div className="grid md:grid-cols-2 gap-12 items-center bg-white/5 p-8 md:p-12 rounded-sm border border-brand-hover/10">
                    <div className="space-y-6">
                        <h3 className="text-2xl font-serif text-brand-hover">Nossa Estrutura</h3>
                        <p className="text-brand-text/80 leading-relaxed">
                            Nosso parque industrial, com 1.000 m2 de área de produção, está em localizado no bairro Santo Antônio em Belo Horizonte. 
                            Além dos equipamentos de alta precisão e desempenho como: Estações de corte à Laser, Router CNC, montagem, serralheria técnica, cabine de pintura e laboratórios de elétrica e eletrônica, contamos como uma equipe especializada em transporte e instalação de estruturas de grande porte com todas as certificações de segurança exigidas pelas normas “XYZ”.
                        </p>
                    </div>
                    <div className="aspect-video overflow-hidden rounded-sm">
                        <img 
                            src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1000" 
                            alt="Industrial Park" 
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                        />
                    </div>
                </div>

                <div className="flex flex-col items-center gap-12 pt-12">
                    <h3 className="text-xl font-serif uppercase tracking-widest text-brand-text/60">Fale Conosco</h3>
                    
                    <div className="grid md:grid-cols-2 gap-8 w-full">
                        {/* Contact 1 */}
                        <div className="bg-white/5 p-8 rounded-sm border border-brand-hover/10 flex flex-col items-center text-center space-y-4">
                            <span className="text-[10px] uppercase tracking-[0.2em] text-brand-hover font-bold">Comercial</span>
                            <h4 className="text-xl font-serif text-brand-text">RODRIGO DOMUSCI</h4>
                            <div className="space-y-2 pt-4 w-full">
                                <a 
                                    href="https://wa.me/5531983315015" 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="flex items-center justify-center gap-2 text-sm hover:text-brand-hover transition-colors"
                                >
                                    <span className="opacity-40 uppercase tracking-widest text-[10px]">WhatsApp:</span>
                                    <span className="font-medium">+55 (31) 9 8331.5015</span>
                                </a>
                                <a 
                                    href="mailto:rodrigo@skymidia.com.br" 
                                    className="flex items-center justify-center gap-2 text-sm hover:text-brand-hover transition-colors"
                                >
                                    <span className="opacity-40 uppercase tracking-widest text-[10px]">E-mail:</span>
                                    <span className="font-medium">rodrigo@skymidia.com.br</span>
                                </a>
                            </div>
                        </div>

                        {/* Contact 2 */}
                        <div className="bg-white/5 p-8 rounded-sm border border-brand-hover/10 flex flex-col items-center text-center space-y-4">
                            <span className="text-[10px] uppercase tracking-[0.2em] text-brand-hover font-bold">Comercial - Arquitetura</span>
                            <h4 className="text-xl font-serif text-brand-text">FERNANDO RIBALDO</h4>
                            <div className="space-y-2 pt-4 w-full">
                                <a 
                                    href="https://wa.me/5531985869051" 
                                    target="_blank" 
                                    rel="noopener noreferrer"
                                    className="flex items-center justify-center gap-2 text-sm hover:text-brand-hover transition-colors"
                                >
                                    <span className="opacity-40 uppercase tracking-widest text-[10px]">WhatsApp:</span>
                                    <span className="font-medium">+55 (31) 9 8586.9051</span>
                                </a>
                                <a 
                                    href="mailto:fernando@skymidia.com.br" 
                                    className="flex items-center justify-center gap-2 text-sm hover:text-brand-hover transition-colors"
                                >
                                    <span className="opacity-40 uppercase tracking-widest text-[10px]">E-mail:</span>
                                    <span className="font-medium">fernando@skymidia.com.br</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
];

export const BRAND_NAME = 'SKYMÍDIA';
export const PRIMARY_COLOR = '#727377'; 
export const ACCENT_COLOR = '#15F0DB'; 
export const TEXT_COLOR = '#F5F5F5';