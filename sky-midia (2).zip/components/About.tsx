/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="bg-brand-text pt-32">
      
      {/* Philosophy Blocks (Formerly Features) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[80vh]">
        <div className="order-2 lg:order-1 relative h-[500px] lg:h-auto overflow-hidden group">
           <img 
             src="https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&q=80&w=1200" 
             alt="Natural Stone Texture" 
             className="absolute inset-0 w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-105"
           />
        </div>
        <div className="order-1 lg:order-2 flex flex-col justify-center p-12 lg:p-24 bg-brand-text">
           <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-dark/60 mb-6">Identidade Visual</span>
           <h3 className="text-4xl md:text-5xl font-serif mb-8 text-brand-dark leading-tight">
             Design que comunica <br/> sua essência.
           </h3>
           <p className="text-lg text-brand-dark/80 font-light leading-relaxed mb-12 max-w-md">
             Criamos identidades visuais que transcendem o estético, capturando a alma do seu negócio e transformando-a em uma linguagem visual poderosa e memorável.
           </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 min-h-[80vh]">
        <div className="flex flex-col justify-center p-12 lg:p-24 bg-brand-text text-brand-dark">
           <span className="text-xs font-bold uppercase tracking-[0.2em] text-brand-dark/60 mb-6">Comunicação Visual</span>
           <h3 className="text-4xl md:text-5xl font-serif mb-8 text-brand-dark leading-tight">
             Impacto que se vê.
           </h3>
           <p className="text-lg text-brand-dark/80 font-light leading-relaxed mb-12 max-w-md">
             De fachadas a sinalização interna, entregamos soluções completas de comunicação visual que garantem que sua marca seja vista e lembrada com clareza e sofisticação.
           </p>
        </div>
        <div className="relative h-[500px] lg:h-auto overflow-hidden group">
           <img 
             src="https://images.pexels.com/photos/6801917/pexels-photo-6801917.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
             alt="Woman sitting on wooden floor reading" 
             className="absolute inset-0 w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-105 brightness-90"
           />
        </div>
      </div>
    </section>
  );
};

export default About;