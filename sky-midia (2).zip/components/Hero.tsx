/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/


import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const images = [
  "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1503387762-592dee58c460?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1626785774573-4b799315345d?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1541535650810-10d26f5c2abb?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1611486212335-132d6282433b?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&q=80&w=2000",
  "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&q=80&w=2000"
];

const Hero: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 7000);

    return () => clearInterval(timer);
  }, []);

  return (
    <section className="relative w-full h-screen min-h-[800px] overflow-hidden bg-brand-bg">
      
      {/* Carousel Background */}
      <div className="absolute inset-0 w-full h-full">
        <AnimatePresence>
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 2.5, ease: "easeInOut" }}
            className="absolute inset-0 w-full h-full"
          >
            <motion.img 
                initial={{ scale: 1.1 }}
                animate={{ scale: 1 }}
                transition={{ duration: 8, ease: "linear" }}
                src={images[currentIndex]} 
                alt={`Slide ${currentIndex + 1}`} 
                className="w-full h-full object-cover grayscale contrast-[0.7] brightness-[0.95]"
            />
          </motion.div>
        </AnimatePresence>
        
        {/* Dark Overlay for Richness */}
        <div className="absolute inset-0 bg-brand-bg/40 mix-blend-multiply z-[1]"></div>
        {/* Subtle Depth Overlay */}
        <div className="absolute inset-0 bg-black/20 z-[2]"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col justify-center items-start text-left md:items-center md:text-center px-6">
        <div className="animate-fade-in-up w-full md:w-auto">
          <h1 className="text-6xl md:text-8xl lg:text-9xl font-serif font-normal text-brand-text tracking-tight mb-8 drop-shadow-sm">
            Somos a <span className="italic text-brand-hover">SKYMÍDIA</span>
          </h1>
          <p className="max-w-2xl mx-0 md:mx-auto text-lg md:text-xl text-brand-text/90 font-light leading-relaxed mb-12 text-shadow-sm">
            Transformamos matérias-primas comuns em projetos de Comunicação Visual, de modo que cada cliente obtenha uma solução sob medida para cada uma das suas necessidades.
          </p>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 animate-bounce text-brand-text/50 z-10">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;
