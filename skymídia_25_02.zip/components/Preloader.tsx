import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PreloaderProps {
  onComplete: () => void;
}

const Preloader: React.FC<PreloaderProps> = ({ onComplete }) => {
  const [isFinished, setIsFinished] = useState(false);
  
  const fullText = "OLÁ !\nSomos a SKYMÍDIA\nTransformamos matérias-primas comuns em projetos de Comunicação Visual";
  const characters = fullText.split("");
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsFinished(true);
      setTimeout(onComplete, 1000);
    }, 8500); // Slightly longer to account for more text
    
    return () => clearTimeout(timer);
  }, [onComplete]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { duration: 0.5 }
    },
    exit: {
      opacity: 0,
      transition: { duration: 0.8, ease: "easeInOut" }
    }
  };

  const charVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 }
  };

  const brandVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1 }
  };

  return (
    <AnimatePresence>
      {!isFinished && (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          exit="exit"
          className="fixed inset-0 z-[999] flex items-center justify-center bg-black px-6"
        >
          <div className="w-full md:w-2/3 text-center">
            <motion.p 
              className="text-2xl md:text-4xl lg:text-5xl font-light leading-tight md:leading-relaxed tracking-tight"
              variants={{
                visible: {
                  transition: {
                    staggerChildren: 0.03,
                    delayChildren: 0.5
                  }
                }
              }}
            >
              {characters.map((char, i) => {
                if (char === "\n") return <br key={i} />;
                
                // "SKYMÍDIA" is from index 14 to 21 in the new string
                const isBrandPart = i >= 14 && i <= 21;
                
                return (
                  <motion.span
                    key={i}
                    variants={isBrandPart ? brandVariants : charVariants}
                    className={isBrandPart ? "font-bold" : ""}
                    style={{ color: isBrandPart ? '#15F0DB' : '#E6E7E9' }}
                  >
                    {char}
                  </motion.span>
                );
              })}
            </motion.p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default Preloader;
